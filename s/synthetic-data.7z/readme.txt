This is the synthetic indoor keyword data used in the paper "Indoor Top-k Keyword-aware Routing Query." IEEE International Conference on Data Engineering. IEEE, 2020.

Synthetic space can be constructed using Par.txt and Door.txt. Shops can be linked with partitions using shopsWithPartition.txt

-------------------------------------------------------------------
Format (Par.txt):
Partition ID \t X1 \t X2 \t Y1 \t Y2 \t Floor \t Room Type \t Linked doors (separated by \t) \n

Room Type:
int STORE = 0;
int HALLWAY = 1;
int STAIRCASE = 2;

-------------------------------------------------------------------
Format (Door.txt):
Door ID \t X \t Y \t Floor \t Linked partitions (separated by \t) \n

-------------------------------------------------------------------
Format (shopWithKey.txt):
Shop ID \t Brand name \t Related keywords (separated by \t) \n

-------------------------------------------------------------------
Format (shopsWithPartition.txt):
Partition ID \t Virtual shop ID \t Shop ID \n


-------------------------------------------------------------------
-------------------------------------------------------------------
Five shopping malls in Hong Kong: 
- City Plaza. http://www.cityplaza.com/en/shopping.aspx/.
- Festival Walk. http://www.festivalwalk.com.hk/en/shopping/.
- Harbour City. http://www.harbourcity.com.hk/en/shop-dine/shop/.
- New Town Plaza. http://www.newtownplaza.com.hk/shopping/.
- Times Square. https://timessquare.com.hk/shopping?lang=en.
-------------------------------------------------------------------
-------------------------------------------------------------------